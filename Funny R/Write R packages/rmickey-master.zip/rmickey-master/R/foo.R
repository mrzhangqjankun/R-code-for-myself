#' A brief introduction to this function.
#' @param x1 explain what is x1
#' @param x2 
#' @return explain what is returned by this function.
#' @export
#' @examples foo()
foo <- function(x1 = 2, x2 = 21) {
  y <- x1 * x2
  return(y)
}
